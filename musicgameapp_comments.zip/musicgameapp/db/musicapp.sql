-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2013 at 02:52 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `musicapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblaccount`
--

CREATE TABLE IF NOT EXISTS `tblaccount` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `sUsername` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sPassword` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sFullname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sPhone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sEmail` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iGender` tinyint(1) DEFAULT NULL,
  `dBirthday` date DEFAULT NULL,
  `sAvatar` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tblaccount`
--

INSERT INTO `tblaccount` (`ID`, `sUsername`, `sPassword`, `sFullname`, `sPhone`, `sEmail`, `iGender`, `dBirthday`, `sAvatar`, `iRole`) VALUES
(16, 'manager ', '21232f297a57a5a743894a0e4a801fc3', 'game data', '444444444', '', NULL, NULL, NULL, 0),
(15, 'Admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin', '0984726234', 'admin@bsp.vn', NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbldatagame`
--

CREATE TABLE IF NOT EXISTS `tbldatagame` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sMusicFile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sAname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sAImage` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sBname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sBImage` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sCname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sCImage` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sAswer` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `dDayPosted` datetime DEFAULT NULL,
  `iStatus` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbldatagame`
--

INSERT INTO `tbldatagame` (`ID`, `sMusicFile`, `sAname`, `sAImage`, `sBname`, `sBImage`, `sCname`, `sCImage`, `sAswer`, `dDayPosted`, `iStatus`) VALUES
(1, 'baby-one-more-time.mp3', 'Britney Spears - Baby One More Time', 'bs.jpg', 'Matt Cardle - Baby One More Time', 'matt-cardle.jpg', 'Madona - Baby One More Time', 'madona.jpg', 'B', NULL, 1),
(2, 'boulevard.mp3', 'Dan Byrd - Boulevard', 'dan-byrd.jpg', 'Divo - Boulevard', 'divo.jpg', 'Jacky Chan - Endlesslove', 'tl.jpg', 'A', NULL, 1),
(3, 'unbreak-my-heart.mp3', 'Toni Braxton - Unbreak My Heart', 'toni-braxton.jpg', 'Justin Timerlake - Unbreak My Heart', 'justin-timerlake.jpg', 'Justin Bebe - Unbreak My Heart', 'jb.jpg', 'A', NULL, 1),
(4, 'Hold-me-for-a-while.mp3', 'Rednex - Hold me for a while', 'rednex.jpg', 'Joan Jett - I Hate Myself For Loving You', 'joanjett .jpg', 'Death Cab For Cutiet - I Hate Myself For Loving You', 'death-cab-for-cutie.jpg', 'A', NULL, 1),
(5, 'Endlesslove.mp3', 'Jacky Chan - Endlesslove', 'tl.jpg', 'Andy Lau - A Better Day', 'andylau.jpg', 'Aaron Kwok Fu Shing - Beautiful Girl ', 'aronkwok.jpg', 'A', NULL, 1),
(6, '40259084-Danh Quen Di Vang - Nhat Tinh Anh.mp3', 'A', '29576788-logo_vuigiaitri_009.gif', 'Danh Quen DI Vang - Nhat TInh Anh', '91979720-logo_vuigiaitri_014.gif', 'C', '52959717-logo_vuigiaitri_021.gif', 'B', '2013-11-05 14:54:56', 1),
(8, '78425777-TinhLo.mp3', 'Le quyen - tinh lo', '2346506-avata_iory.JPG', 'B', '13151198-doremonavata.jpg', 'C', '45524310-avata-pro.jpg', 'A', '2013-11-05 14:55:32', 1),
(9, '6080651-Voi Vang - MTV.mp3', 'Voi Vang - MTV', '68202533-avata-pro.jpg', 'b', '8695781-avata_doremon.JPG', 'b', '11777915-Kof-wallpapers.jpg', 'A', '2013-11-05 14:58:56', 1),
(10, '34205342-dung thuong toi.mp3', 'Dung Thuong Toi - DVH', '71509709-logo_vuigiaitri_002.gif', 'Khong Phai Em - DVH', '47225438-logo_vuigiaitri_014.gif', 'Thanh Pho Buon - DVH', '32861709-logo_vuigiaitri_026.gif', 'A', '2013-11-05 17:11:59', 1),
(11, '76182421-Con Lai Gi Khi Anh Vang Em - Ho Trung Dung.mp3', 'Con Lai gi - HTD', '16408722-logo_vuigiaitri_004.gif', 'Tiec thuong - HTD', '60864810-chung nhan dep trai.jpg', 'Hoi nguoi tinh - HTD', '187515-chung nhan doc than.jpg', 'A', '2013-11-05 17:18:58', 1),
(12, '63653282-Quen Thuoc - Thuy Khanh.mp3', 'Quen Thuoc - VTV', '20586604-1pt7.jpg', 'Quen - VTV', '7347617-12lh7.jpg', 'Nho - VTV', '1673625-15wl9.jpg', 'A', '2013-11-05 17:20:21', 1),
(13, '98426101-Bai Ca Tinh Nho - Dam Vinh Hung.mp3', 'Bai ca tinh nho - DVH', '77516054-appalled.png', 'Tien dua - LH', '14743372-big_grin.png', 'Yeu Lam - LH', '95275276-ashamed.png', 'A', '2013-11-05 17:21:45', 1),
(14, '40065336-Thu sau.mp3', 'Thu Sau - Nhu y', '34272390-b12hv6.jpg', 'Thu Can - Nhu Y', '1611084-businessman.png', 'Thu quyen ru - Hoai linh', '35943867-sitnky.png', 'A', '2013-11-05 18:29:10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE IF NOT EXISTS `tbluser` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `FBID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sFullName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sEmail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sUserName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sAvata` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iScore` int(11) DEFAULT NULL,
  `iRate` int(11) NOT NULL,
  `dDayPlay` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`ID`, `FBID`, `sFullName`, `sEmail`, `sUserName`, `sAvata`, `iScore`, `iRate`, `dDayPlay`) VALUES
(2, '12344566789', 'Dinh Hieu', 'dinhhieu_it@yahoo.com', 'dinhhieu_it', 'default.png', 6789, 15, '2013-11-05 00:00:00'),
(3, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(4, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(5, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(6, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(7, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(8, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(9, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(10, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(11, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(12, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(13, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(14, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(15, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(16, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(17, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(18, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(19, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(20, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(21, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(22, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(23, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00'),
(24, '0987654345678', 'hieu', 'hieu@yahoo.com', 'hieudinh', 'default.jpg', 1234, 12, '2013-11-05 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
