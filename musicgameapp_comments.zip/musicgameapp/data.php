<?php
define('limit',10);
?>
